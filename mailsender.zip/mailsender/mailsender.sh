#!/bin/bash

# Controlla se il pack "mailx" è installato
echo "Controllo l'installazione di Mailx..."
CHECK=$(yum list installed | grep mailx)

# Se la variabile check è NULL, ossia mailx non è installato, installa il pack
if [ -z "$CHECK" ]; then echo "Mailx mancante, installo il pacchetto" | yum install mailx -y; else echo "Mailx rilevato"; fi

# Estrapola le mail dal file di testo
MAILS=$(cat /home/syncsec/DCK-ANUKO/mailsender/list.txt)

# Per ogni mail manda il promemoria
for i in $MAILS
do
	echo "Invio email a" $i
	mail -s "Promemoria Time Tracker" -r "Anuko<webcld01@syncsec.priv>" $i < /home/syncsec/DCK-ANUKO/mailsender/message.txt
done

echo "E-mail inviate"
